/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project_305;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDatabase {

    public static void main(String[] args) {
        Connection con = null;
        try {
            // Set the path for the database
            String ConnectionURL = "jdbc:mysql://localhost:3306";

            // Create connection
            con = DriverManager.getConnection(ConnectionURL, "root", "3389");

            // Create statement object
            Statement st = con.createStatement();

            String database = "EmployeeDB";

            // Execute SQL statement to create the database
            st.executeUpdate("CREATE DATABASE " + database);

            System.out.println("1 row(s) affected");

            // Close connection
            con.close();
        } catch (SQLException s) {
            System.out.println("SQL statement is not executed!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
