/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package project_305;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 *
 * @author shahadhani
 */
public class Sever2UI extends javax.swing.JFrame {

    // Server variables
    private ServerSocket server;
    private int[] employeesID = new int[6];
    private int clientNum = 1;
    private ServerSocket serverSocket;

    public Sever2UI() {

        initComponents();
    }

    // Method to start the server 
    private void startServer() {
        // Create a new thread using lambda expression
        new Thread(() -> {
            try {
                // Create a server socket on port 8302
                server = new ServerSocket(8302);

                // Display a message in the serverTextArea 
                serverTextArea.append("Server waiting for connection...\n");

                // Initialize employee IDs 
                for (int i = 0; i < employeesID.length; i++) {
                    employeesID[i] = i + 1000;
                }

                // Continuously listen for incoming connections
                while (true) {
                    // Accept a client socket
                    Socket socket = server.accept();

                    // Display a message in the serverTextArea indicating the if there is new client connection 
                    serverTextArea.append("\n" + "Server: Swapping client: " + clientNum + "\n");

                    EmployeeHandler handler = new EmployeeHandler(socket, clientNum);

                    Thread thread = new Thread(handler);

                    thread.start();

                    clientNum++;

                }
            } catch (IOException ex) {

                Logger.getLogger(Sever2UI.class.getName()).log(Level.SEVERE, null, ex);
            }
        }).start(); // Start the thread
    }

    // Inner class representing a handler for each connected employee (client)
    private class EmployeeHandler implements Runnable {

        // Socket and client number variables
        private Socket socket;

        private int clientNum;

        // Constructor for the EmployeeHandler
        public EmployeeHandler(Socket socket, int clientNum) {
            this.socket = socket;

            this.clientNum = clientNum;
        }

        // Run method to handle communication with the client
        public void run() {
            try {
                // Create reader and writer for the client's socket
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                BufferedWriter out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));

                // Display a message in the serverTextArea indicating the Ip address of client connection 
                serverTextArea.append("Client connected via: " + socket.getInetAddress() + "\n");

                // Send a welcome message to the client
                out.write(" Welcome, please provide your Employee ID:\n");
                out.flush();

                // Read client input in a loop
                String input;
                while ((input = in.readLine()) != null) {
                    // Parse the input as an integer representing the employee ID
                    int employeeID = Integer.parseInt(input.trim());

                    // Display the client's message in the serverTextArea
                    serverTextArea.append("Client " + clientNum + " says: " + input + "\n");

                    // Check if the employee ID is valid
                    if (isValidEmployeeID(employeeID)) {
                        // Send a message indicating that the gate will open
                        out.write(" Welcome, The gate will open\n");
                        out.flush();
                        break;
                    } else {
                        // Send a message indicating that the gate will not open
                        out.write(" Sorry you are not allowed to get in (No reservation),\nThe gate will NOT open\n");
                        out.flush();
                        break;
                    }
                }
            } catch (IOException | NumberFormatException e) {

                e.printStackTrace();
            } finally {
                try {
                    // Close the socket
                    socket.close();
                } catch (IOException ex) {

                    ex.printStackTrace();
                }
            }
        }
    }

// Method to check if a given employee ID is valid
    private boolean isValidEmployeeID(int employeeID) {
        // Iterate through the employeesID array to check for a match
        for (int id : employeesID) {
            // If the current element matches the given employeeID, return true
            if (employeeID == id) {
                return true;
            }
        }
        // If no match is found, return false
        return false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Sever2UI serverGUI = new Sever2UI();
                serverGUI.setVisible(true);
            }
        });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        startButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        serverTextArea = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        startButton.setFont(new java.awt.Font("Hoefler Text", 0, 18)); // NOI18N
        startButton.setText("Start ");
        startButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startButtonActionPerformed(evt);
            }
        });
        getContentPane().add(startButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 350, 80, 30));

        serverTextArea.setColumns(20);
        serverTextArea.setRows(5);
        jScrollPane1.setViewportView(serverTextArea);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 390, 350, 240));

        jLabel2.setFont(new java.awt.Font("Hoefler Text", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Server :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 350, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_305/Scann.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 440, 750));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void startButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startButtonActionPerformed
        startServer();


    }//GEN-LAST:event_startButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea serverTextArea;
    private javax.swing.JButton startButton;
    // End of variables declaration//GEN-END:variables
}
