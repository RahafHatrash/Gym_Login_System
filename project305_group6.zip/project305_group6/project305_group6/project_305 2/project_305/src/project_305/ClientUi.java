/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_305;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import static java.lang.System.out;
import java.net.*;
import java.util.Scanner;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

public class ClientUi extends javax.swing.JFrame {

    // Socket for communication with the server
    private Socket socket;

    // PrintWriter for sending messages to the server
    private PrintWriter out;

    // Scanner for receiving messages from the server
    private Scanner in;

    public ClientUi() {

        initComponents();
        Scan.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the ID entered in the text field
                String message = enterdID.getText();

                // Send the message (id of member) to the server using PrintWriter
                out.println(message);

            }
        });

        try {
            // Create a socket to connect to the server at "127.0.0.1" on port 8302
            socket = new Socket("127.0.0.1", 8302);

            // Initialize PrintWriter for sending messages to the server
            out = new PrintWriter(socket.getOutputStream(), true);

            // Initialize Scanner for receiving messages from the server
            in = new Scanner(socket.getInputStream());

            // Start a new thread to listen for messages from the server (if this line doesn't exist ,can't see or print the messages coming from server) 
            new Thread(new ClientUi.ServerListener()).start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // Inner class representing a listener for messages from the server
    private class ServerListener implements Runnable {

        // Run method to handle incoming messages from the server
        public void run() {
            try {
                // Continue listening for messages while the server is sending
                while (in.hasNextLine()) {
                    // Read the next line as a message from the server 
                    String message = in.nextLine();

                    // Append the message comming from the server to the text area with specified color
                    appendToChatArea("Server: " + message + "\n", Color.RED, ServerPanel);
                }

               // Hide UI components after enterd id 
                enterdID.setVisible(false);
                Scan.setVisible(false);
                jLabel2.setVisible(false);
            } catch (Exception e) {
                // Print the stack trace if an exception occurs during message handling
                e.printStackTrace();
            }
        }
    }

    // Method to append text to a JTextPane with a specified color
    private void appendToChatArea(String msg, Color color, JTextPane textPane) {

        StyledDocument doc = textPane.getStyledDocument();
        // Create a new Style and set its foreground color
        Style style = textPane.addStyle("Style", null);
        StyleConstants.setForeground(style, color);

        try {
            // Insert the message with the specified style into the document
            doc.insertString(doc.getLength(), msg, style);
        } catch (BadLocationException e) {

            e.printStackTrace();
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        ServerPanel = new javax.swing.JTextPane();
        enterdID = new javax.swing.JTextField();
        Scan = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ServerPanel.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jScrollPane2.setViewportView(ServerPanel);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 360, 240));

        enterdID.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        enterdID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                enterdIDActionPerformed(evt);
            }
        });
        getContentPane().add(enterdID, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 620, 200, 30));

        Scan.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        Scan.setText("Scan");
        Scan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ScanActionPerformed(evt);
            }
        });
        getContentPane().add(Scan, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 620, 110, 30));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ID:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 590, -1, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Client:");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 310, -1, -1));

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_305/Scann.jpg"))); // NOI18N
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 750));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void enterdIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enterdIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_enterdIDActionPerformed

    private void ScanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ScanActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_ScanActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ClientUi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ClientUi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ClientUi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ClientUi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ClientUi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Scan;
    private javax.swing.JTextPane ServerPanel;
    private javax.swing.JTextField enterdID;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
