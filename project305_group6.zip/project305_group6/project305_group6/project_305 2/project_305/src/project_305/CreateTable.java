/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project_305;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;


public class CreateTable {

    public static void main(String[] args) throws SQLException {
        // Database connection URL , specifying the database name 'EmployeeDB'
        String connectionURL = "jdbc:mysql://localhost:3306/EmployeeDB";

        // Establish a connection to the database using the specified URL, username, and password
        Connection con = DriverManager.getConnection(connectionURL, "root", "3389");

        // Create a Statement object for executing SQL queries
        Statement st = con.createStatement();

        // SQL query to create the 'employee' table with columns 'Id', 'Date', and 'Time'
        String sql = "CREATE TABLE employee ("
                + "Id INT,"
                + "Date VARCHAR(255),"
                + "Time  VARCHAR(255)"
                + ")";

        // Execute the SQL query to create the table
        st.executeUpdate(sql);

        // Prepared statement for inserting data into the 'employee' table
        PreparedStatement ps = con.prepareStatement("INSERT INTO employee "
                + "(Id, Date, Time)"
                + "VALUES (?, ?, ?)");

        // Random number generator for generating employee IDs
        Random randomNum = new Random();
        int Id;

        // Loop to insert sample data into the 'employee' table
        for (int i = 0; i < 6; i++) {
            
            for (int j = 1; j < 7; j++) {
                
                // Generate a unique employee ID in the range [1001, 1006]
                int employeeId = 1000 + j;

                // Generate random month, hour, and minutes for the date and time fields
                int month = randomNum.nextInt(12) + 1;
                int hour = randomNum.nextInt(10) + 1;
                int minutes = randomNum.nextInt(60);

                // Construct date and time strings 
                String date = "2023-" + month + "-" + j;
                String time = hour + ":" + minutes;

                // Set parameters in the prepared statement
                ps.setInt(1, employeeId);
                ps.setString(2, date);
                ps.setString(3, time);

                // Execute the prepared statement to insert data into the table
                ps.executeUpdate();
            }
        }
    }
}
