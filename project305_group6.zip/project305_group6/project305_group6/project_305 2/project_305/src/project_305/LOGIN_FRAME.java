/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project_305;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class LOGIN_FRAME extends javax.swing.JFrame {

    static boolean flag = false;
    static int adminID = 50;

    public LOGIN_FRAME() {
        initComponents();
    }

    public String getEnteredID() {
        return idText.getText();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        idText = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("id");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(153, 0, 0));
        jLabel2.setFont(new java.awt.Font("Hoefler Text", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 240, 150, 20));

        idText.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        idText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idTextActionPerformed(evt);
            }
        });
        jPanel1.add(idText, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 260, 210, 40));

        jPasswordField1.setFont(new java.awt.Font("Times New Roman", 0, 12)); // NOI18N
        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });
        jPanel1.add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 320, 210, 40));

        jButton1.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jButton1.setText("Log In");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 480, 120, 40));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project_305/LoginInterface.png"))); // NOI18N
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 750));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 750));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void idTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idTextActionPerformed


    }//GEN-LAST:event_idTextActionPerformed

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed

        String pass = jPasswordField1.getText();
    }//GEN-LAST:event_jPasswordField1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        JOptionPane j = new JOptionPane();
        try {
            // Get the entered ID from the text field
            String id = idText.getText();

            int id1 = Integer.parseInt(id);

            // Read data from the "members.txt" file
            FileReader FILE = new FileReader(new File("members.txt"));
            BufferedReader br = new BufferedReader(FILE);

            String line;
            flag = false;

            // Loop through each line in the file
            while ((line = br.readLine()) != null) {
                // Extract the ID from the line 
                String id2 = line.substring(0, 3);

                // convert id2 to integer
                int id22 = Integer.valueOf(id2);

                // Split the line into columns using a comma as a delimiter
                String[] columns = line.split(",");

                // Check if the entered ID matches an admin ID  (50)
                if (id1 == adminID) {

                    // Open the Admin_UI page 
                    Admin_UI admin = new Admin_UI();
                    admin.show();
                    dispose();
                    break;
                }

                // Check if the entered ID matches the ID in the file
                if (id1 == id22) {

                    // Extract the name from the columns
                    String name1 = columns[1];

                    // Open the ReservationPage_UI
                    flag = true;

                    ReservationPage_UI RP = new ReservationPage_UI();

                    RP.show();

                    dispose();

                    RP.setLabelText(name1);
                    break;
                }
            }

            // Display an error message if the login was unsuccessful
            if (flag == false) {
                jLabel2.setText("Wrong ID, please try again");
            }

            // Close the file reader and file
            br.close();
            FILE.close();

        } catch (NumberFormatException e) {
            // Display an error message if a NumberFormatException occurs
            j.showMessageDialog(null, e.getMessage());
        } catch (FileNotFoundException ex) {
            // Log and handle a FileNotFoundException
            Logger.getLogger(LOGIN_FRAME.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            // Log and handle an IOException
            Logger.getLogger(LOGIN_FRAME.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
//GEN-LAST:event_jButton1ActionPerformed
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LOGIN_FRAME.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LOGIN_FRAME.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LOGIN_FRAME.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LOGIN_FRAME.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LOGIN_FRAME().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField idText;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    // End of variables declaration//GEN-END:variables
}
